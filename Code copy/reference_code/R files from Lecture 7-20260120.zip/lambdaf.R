# This function gives the NPP intensity at time t


lambdaf = function(t){
  
  return(3 + (4/(t+1)))
  
}